package SHAPES;

public abstract class Shape {
    private int xCoord;
    private int yCoord;

    public Shape(){
        xCoord = 1;
        yCoord = 1;
    }

    public Shape(int x, int y){
        xCoord = x;
        yCoord = y;
    }

    public void printProperties(){
        System.out.println("xCoord = "+xCoord);
        System.out.println("yCoord = "+yCoord);
    }

    public abstract int shapeArea();
}
