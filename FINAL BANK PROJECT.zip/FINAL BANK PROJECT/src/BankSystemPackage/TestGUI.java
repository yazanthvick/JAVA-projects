package BankSystemPackage;

import javax.swing.JOptionPane;
import javax.swing.JButton; // this is the new button as part of swing package
import java.awt.Button; // the old Java UI package that replaced by swing

public class TestGUI {

    public static void main(String[] args) {
       // JOptionPane.showMessageDialog(null,"Hi How are you?");
      /* String value1,value2;
       int number1, number2, result;
       value1 = JOptionPane.showInputDialog("Please enter first number");
       value2 = JOptionPane.showInputDialog("Please enter second number");
       number1 = Integer.parseInt(value1);
       number2 = Integer.parseInt(value2);
       result = number1+number2;
       JOptionPane.showMessageDialog(null, result);
       */

      //JOptionPane.showMessageDialog(null, Integer.parseInt(JOptionPane.showInputDialog("Please enter number 1:"))+Integer.parseInt(JOptionPane.showInputDialog("Please enter number 2:")));
    }
}
