package BankSystemPackage;

public interface CredentialUserTypes {
    public static final int HEADOFFICE_USER = 1;
    public static final int BRANCH_USER = 2;
    public static final int CUSTOMER_USER = 3;
}
